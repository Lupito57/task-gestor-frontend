import { Component, inject } from '@angular/core';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { TaskService } from '../../../../core/services/task.service';
import { TaskListComponent } from '../task-list/task-list.component';

@Component({
  selector: 'app-task-dashboard',
  standalone: true,
  imports: [MatProgressSpinnerModule],
  templateUrl: './task-dashboard.component.html',
  styleUrls: ['./task-dashboard.component.scss']
})
export class TaskDashboardComponent {
  ts = inject(TaskService);
}

